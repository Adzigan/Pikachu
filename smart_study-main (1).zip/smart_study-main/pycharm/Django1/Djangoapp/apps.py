from django.apps import AppConfig


class DdjandoappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Djangoapp'
    verbose_name = 'Новостной портал'
