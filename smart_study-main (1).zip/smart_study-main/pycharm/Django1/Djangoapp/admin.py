from django.contrib import admin
from .models import Groups, News

admin.site.register(Groups)
admin.site.register(News)
